# No custom shrinking rules are required. Release minification is disabled by default.
