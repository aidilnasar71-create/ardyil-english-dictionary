package com.ardyil.dictionary;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.media.MediaRecorder;
import java.io.File;
import java.io.FileInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;

import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

import java.util.ArrayList;
import java.util.Locale;

/** Native Android shell and native speech services for the offline ARDYIL dictionary. */
public class MainActivity extends Activity {
    private static final int REQUEST_RECORD_AUDIO = 7314;
    private static final String APP_ASSET_HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + APP_ASSET_HOST + "/assets/index.html";

    private WebView webView;
    private PermissionRequest pendingAudioRequest;
    private WebViewAssetLoader assetLoader;
    private TextToSpeech textToSpeech;
    private boolean ttsReady = false;
    private SpeechRecognizer speechRecognizer;
    private boolean pendingRecognitionAfterPermission = false;
    private String pendingRecognitionLanguage = "en-US";
    private boolean pendingNativeRecording = false;
    private MediaRecorder audioRecorder;
    private File recordingFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureSystemBars();

        textToSpeech = new TextToSpeech(this, status -> {
            ttsReady = status == TextToSpeech.SUCCESS;
            if (ttsReady) {
                textToSpeech.setLanguage(Locale.US);
            }
            notifyJavascript("window.onAndroidTtsReady && window.onAndroidTtsReady(" + (ttsReady ? "true" : "false") + ")");
        });

        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(247, 246, 251));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) settings.setSafeBrowsingEnabled(true);

        webView.addJavascriptInterface(new AndroidVoiceBridge(), "AndroidVoice");
        webView.setWebViewClient(new WebViewClientCompat() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                return !"https".equalsIgnoreCase(uri.getScheme())
                        || !APP_ASSET_HOST.equalsIgnoreCase(uri.getHost());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> handleWebPermissionRequest(request));
            }
            @Override
            public void onPermissionRequestCanceled(PermissionRequest request) {
                if (pendingAudioRequest == request) pendingAudioRequest = null;
            }
        });

        FrameLayout root = new FrameLayout(this);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        if (savedInstanceState == null) webView.loadUrl(START_URL);
        else webView.restoreState(savedInstanceState);
    }

    private class AndroidVoiceBridge {
        @JavascriptInterface
        public void speak(String text, String language, float rate) {
            runOnUiThread(() -> speakNative(text, language, rate));
        }
        @JavascriptInterface
        public void stopSpeaking() {
            runOnUiThread(() -> { if (textToSpeech != null) textToSpeech.stop(); });
        }
        @JavascriptInterface
        public boolean isSpeechRecognitionAvailable() {
            return SpeechRecognizer.isRecognitionAvailable(MainActivity.this);
        }
        @JavascriptInterface
        public void startListening(String language) {
            runOnUiThread(() -> requestAndStartRecognition(language));
        }
        @JavascriptInterface
        public void startAudioRecording() {
            runOnUiThread(() -> requestAndStartNativeRecording());
        }
        @JavascriptInterface
        public void stopAudioRecording() {
            runOnUiThread(() -> stopNativeRecording());
        }
        @JavascriptInterface
        public void stopListening() {
            runOnUiThread(() -> {
                if (speechRecognizer != null) releaseSpeechRecognizer(speechRecognizer, true);
        if (audioRecorder != null) { try { audioRecorder.stop(); } catch (Exception ignored) {} releaseAudioRecorder(); }
        if (recordingFile != null) recordingFile.delete();
            });
        }
    }

    private void speakNative(String text, String language, float rate) {
        if (text == null || text.trim().isEmpty()) {
            notifyJavascript("window.onAndroidTtsError && window.onAndroidTtsError('empty-text')");
            return;
        }
        if (!ttsReady || textToSpeech == null) {
            notifyJavascript("window.onAndroidTtsError && window.onAndroidTtsError('tts-not-ready')");
            return;
        }
        try {
            Locale locale = Locale.forLanguageTag(language == null || language.isEmpty() ? "en-US" : language);
            int languageResult = textToSpeech.setLanguage(locale);
            if (languageResult == TextToSpeech.LANG_MISSING_DATA || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                notifyJavascript("window.onAndroidTtsError && window.onAndroidTtsError('language-not-supported')");
                return;
            }
            textToSpeech.setSpeechRate(Math.max(0.5f, Math.min(1.25f, rate)));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ardyil-tts");
            } else {
                textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null);
            }
        } catch (Exception e) {
            notifyJavascript("window.onAndroidTtsError && window.onAndroidTtsError('tts-error')");
        }
    }

    private void requestAndStartRecognition(String language) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            notifyJavascript("window.onAndroidSpeechError && window.onAndroidSpeechError('unavailable')");
            return;
        }

        String requestedLanguage = (language == null || language.trim().isEmpty())
                ? "en-US" : language.trim();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingRecognitionAfterPermission = true;
            pendingRecognitionLanguage = requestedLanguage;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO);
            return;
        }

        startRecognition(requestedLanguage);
    }

    /** Must be called on the main thread. Clears the field before destroy so late callbacks are ignored. */
    private void releaseSpeechRecognizer(SpeechRecognizer recognizer, boolean cancel) {
        if (recognizer == null) return;
        if (speechRecognizer == recognizer) speechRecognizer = null;
        if (cancel) {
            try { recognizer.cancel(); } catch (Exception ignored) {}
        }
        try { recognizer.destroy(); } catch (Exception ignored) {}
    }

    private void startRecognition(String language) {
        SpeechRecognizer recognizer = null;
        try {
            // A previous recognition session must be fully torn down before a new one starts.
            if (speechRecognizer != null) releaseSpeechRecognizer(speechRecognizer, true);
        if (audioRecorder != null) { try { audioRecorder.stop(); } catch (Exception ignored) {} releaseAudioRecorder(); }
        if (recordingFile != null) recordingFile.delete();

            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer = recognizer;
            final SpeechRecognizer activeRecognizer = recognizer;

            activeRecognizer.setRecognitionListener(new RecognitionListener() {
                private boolean isCurrentSession() {
                    return speechRecognizer == activeRecognizer;
                }

                @Override public void onReadyForSpeech(Bundle params) {
                    if (isCurrentSession()) {
                        notifyJavascript("window.onAndroidSpeechStatus && window.onAndroidSpeechStatus('listening')");
                    }
                }

                @Override public void onBeginningOfSpeech() {
                    if (isCurrentSession()) {
                        notifyJavascript("window.onAndroidSpeechStatus && window.onAndroidSpeechStatus('hearing')");
                    }
                }

                @Override public void onRmsChanged(float rmsdB) {}
                @Override public void onBufferReceived(byte[] buffer) {}

                @Override public void onEndOfSpeech() {
                    if (isCurrentSession()) {
                        notifyJavascript("window.onAndroidSpeechStatus && window.onAndroidSpeechStatus('processing')");
                    }
                }

                @Override public void onError(int error) {
                    if (!isCurrentSession()) return;
                    releaseSpeechRecognizer(activeRecognizer, false);
                    notifyJavascript("window.onAndroidSpeechError && window.onAndroidSpeechError('" + speechErrorName(error) + "')");
                }

                @Override public void onResults(Bundle results) {
                    if (!isCurrentSession()) return;
                    ArrayList<String> matches = results == null ? null :
                            results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String best = (matches == null || matches.isEmpty()) ? "" : matches.get(0);
                    releaseSpeechRecognizer(activeRecognizer, false);
                    if (best.trim().isEmpty()) {
                        notifyJavascript("window.onAndroidSpeechError && window.onAndroidSpeechError('no-match')");
                    } else {
                        notifyJavascript("window.onAndroidSpeechResult && window.onAndroidSpeechResult(" + JSONObjectQuote.quote(best) + ")");
                    }
                }

                @Override public void onPartialResults(Bundle partialResults) {
                    if (isCurrentSession()) {
                        notifyJavascript("window.onAndroidSpeechStatus && window.onAndroidSpeechStatus('hearing')");
                    }
                }

                @Override public void onEvent(int eventType, Bundle params) {}
            });

            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language);
            intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            // Do not force offline-only recognition: many Android devices have no downloaded
            // English acoustic model. Let the installed recognition service choose its available path.
            intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false);

            notifyJavascript("window.onAndroidSpeechStatus && window.onAndroidSpeechStatus('starting')");
            activeRecognizer.startListening(intent);
        } catch (SecurityException e) {
            releaseSpeechRecognizer(recognizer, true);
            notifyJavascript("window.onAndroidSpeechError && window.onAndroidSpeechError('permission')");
        } catch (Exception e) {
            releaseSpeechRecognizer(recognizer, true);
            notifyJavascript("window.onAndroidSpeechError && window.onAndroidSpeechError('start-failed')");
        }
    }


    private void requestAndStartNativeRecording() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingNativeRecording = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO);
            return;
        }
        startNativeRecording();
    }

    private void startNativeRecording() {
        try {
            if (audioRecorder != null) stopNativeRecording();
            recordingFile = File.createTempFile("ardyil-recording-", ".m4a", getCacheDir());
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) audioRecorder = new MediaRecorder(this);
            else audioRecorder = new MediaRecorder();
            audioRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            audioRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            audioRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            audioRecorder.setAudioSamplingRate(44100);
            audioRecorder.setAudioEncodingBitRate(96000);
            audioRecorder.setOutputFile(recordingFile.getAbsolutePath());
            audioRecorder.setOnErrorListener((mr, what, extra) -> {
                releaseAudioRecorder();
                notifyJavascript("window.onAndroidRecordingError && window.onAndroidRecordingError('recording-error')");
            });
            audioRecorder.prepare();
            audioRecorder.start();
            notifyJavascript("window.onAndroidRecordingStarted && window.onAndroidRecordingStarted()");
        } catch (Exception e) {
            releaseAudioRecorder();
            notifyJavascript("window.onAndroidRecordingError && window.onAndroidRecordingError('start-failed')");
        }
    }

    private void stopNativeRecording() {
        if (audioRecorder == null) return;
        boolean saved = false;
        try {
            audioRecorder.stop();
            saved = recordingFile != null && recordingFile.exists() && recordingFile.length() > 0;
        } catch (RuntimeException ignored) {
        } finally {
            releaseAudioRecorder();
        }
        if (!saved) {
            notifyJavascript("window.onAndroidRecordingError && window.onAndroidRecordingError('empty-recording')");
            return;
        }
        try (FileInputStream in = new FileInputStream(recordingFile); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192]; int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            String encoded = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
            notifyJavascript("window.onAndroidRecordingReady && window.onAndroidRecordingReady('" + encoded + "')");
        } catch (IOException e) {
            notifyJavascript("window.onAndroidRecordingError && window.onAndroidRecordingError('save-failed')");
        } finally {
            if (recordingFile != null) recordingFile.delete();
            recordingFile = null;
        }
    }

    private void releaseAudioRecorder() {
        if (audioRecorder != null) {
            try { audioRecorder.reset(); } catch (Exception ignored) {}
            try { audioRecorder.release(); } catch (Exception ignored) {}
            audioRecorder = null;
        }
    }

    private String speechErrorName(int error) {
        switch (error) {
            case SpeechRecognizer.ERROR_AUDIO: return "audio";
            case SpeechRecognizer.ERROR_CLIENT: return "client";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "permission";
            case SpeechRecognizer.ERROR_NETWORK: return "network";
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: return "network-timeout";
            case SpeechRecognizer.ERROR_NO_MATCH: return "no-match";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "busy";
            case SpeechRecognizer.ERROR_SERVER: return "server";
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: return "timeout";
            case SpeechRecognizer.ERROR_TOO_MANY_REQUESTS: return "too-many-requests";
            case SpeechRecognizer.ERROR_SERVER_DISCONNECTED: return "server-disconnected";
            case SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED: return "language-not-supported";
            case SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE: return "language-unavailable";
            default: return "unknown";
        }
    }

    private void notifyJavascript(String script) {
        runOnUiThread(() -> {
            if (webView != null && !isFinishing() && !isDestroyed()) webView.evaluateJavascript(script, null);
        });
    }

    private static class JSONObjectQuote {
        static String quote(String value) {
            if (value == null) return "\"\"";
            StringBuilder out = new StringBuilder("\"");
            for (int i = 0; i < value.length(); i++) {
                char c = value.charAt(i);
                if (c == '"' || c == '\\') out.append('\\').append(c);
                else if (c == '\n') out.append("\\n");
                else if (c == '\r') out.append("\\r");
                else if (c == '\t') out.append("\\t");
                else if (c < 0x20) out.append(String.format("\\u%04x", (int)c));
                else out.append(c);
            }
            return out.append('"').toString();
        }
    }

    private void configureSystemBars() {
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(23, 21, 43));
        window.setNavigationBarColor(Color.rgb(23, 21, 43));
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.setNavigationBarContrastEnforced(false);
            window.setStatusBarContrastEnforced(false);
        }
    }

    private void handleWebPermissionRequest(PermissionRequest request) {
        if (isFinishing() || isDestroyed()) { request.deny(); return; }
        Uri origin = request.getOrigin();
        if (origin == null || !"https".equalsIgnoreCase(origin.getScheme())
                || !APP_ASSET_HOST.equalsIgnoreCase(origin.getHost())) { request.deny(); return; }
        boolean audioRequested = false;
        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) audioRequested = true;
            else { request.deny(); return; }
        }
        if (!audioRequested) { request.deny(); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            return;
        }
        if (pendingAudioRequest != null) pendingAudioRequest.deny();
        pendingAudioRequest = request;
        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_RECORD_AUDIO) return;
        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        PermissionRequest request = pendingAudioRequest;
        pendingAudioRequest = null;
        if (request != null) {
            if (granted && !isFinishing() && !isDestroyed())
                request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            else request.deny();
        }
        if (pendingNativeRecording) {
            pendingNativeRecording = false;
            if (granted) startNativeRecording();
            else notifyJavascript("window.onAndroidRecordingError && window.onAndroidRecordingError('permission')");
        }
        if (pendingRecognitionAfterPermission) {
            pendingRecognitionAfterPermission = false;
            if (granted) startRecognition(pendingRecognitionLanguage);
            else notifyJavascript("window.onAndroidSpeechError && window.onAndroidSpeechError('permission')");
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (pendingAudioRequest != null) { pendingAudioRequest.deny(); pendingAudioRequest = null; }
        if (speechRecognizer != null) releaseSpeechRecognizer(speechRecognizer, true);
        if (audioRecorder != null) { try { audioRecorder.stop(); } catch (Exception ignored) {} releaseAudioRecorder(); }
        if (recordingFile != null) recordingFile.delete();
        if (textToSpeech != null) { textToSpeech.stop(); textToSpeech.shutdown(); textToSpeech = null; }
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidVoice");
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
