package com.ardyil.dictionary;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.provider.MediaStore;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebResourceResponse;
import android.widget.FrameLayout;

import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Locale;

/** Native Android shell and native speech services for the offline ARDYIL dictionary. */
public class MainActivity extends Activity {
    private static final int REQUEST_RECORD_AUDIO = 7314;
    private static final String APP_ASSET_HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + APP_ASSET_HOST + "/assets/index.html";

    private WebView webView;
    private PermissionRequest pendingAudioRequest;
    private WebViewAssetLoader assetLoader;
    private TextToSpeech textToSpeech;
    private boolean ttsReady = false;
    private SpeechRecognizer speechRecognizer;
    private boolean pendingRecognitionAfterPermission = false;
    private String pendingRecognitionLanguage = "en-US";

    // Native AAC/MPEG-4 recording; this avoids relying on WebView MediaRecorder support.
    private MediaRecorder mediaRecorder;
    private File activeRecordingFile;
    private boolean pendingRecordingStart = false;
    private boolean pendingRecordingPermissionCallback = false;
    private boolean permissionRequestInFlight = false;
    private long recordingStartedAtMs = 0L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureSystemBars();

        textToSpeech = new TextToSpeech(this, status -> {
            ttsReady = status == TextToSpeech.SUCCESS;
            if (ttsReady) {
                textToSpeech.setLanguage(Locale.US);
            }
            notifyJavascript("window.onAndroidTtsReady && window.onAndroidTtsReady(" + (ttsReady ? "true" : "false") + ")");
        });

        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/recordings/", this::openRecordingAsset)
                .build();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(247, 246, 251));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) settings.setSafeBrowsingEnabled(true);

        webView.addJavascriptInterface(new AndroidVoiceBridge(), "AndroidVoice");
        webView.setWebViewClient(new WebViewClientCompat() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                return !"https".equalsIgnoreCase(uri.getScheme())
                        || !APP_ASSET_HOST.equalsIgnoreCase(uri.getHost());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> handleWebPermissionRequest(request));
            }
            @Override
            public void onPermissionRequestCanceled(PermissionRequest request) {
                if (pendingAudioRequest == request) pendingAudioRequest = null;
            }
        });

        FrameLayout root = new FrameLayout(this);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        if (savedInstanceState == null) webView.loadUrl(START_URL);
        else webView.restoreState(savedInstanceState);
    }

    private class AndroidVoiceBridge {
        @JavascriptInterface
        public void speak(String text, String language, float rate) {
            runOnUiThread(() -> speakNative(text, language, rate));
        }
        @JavascriptInterface
        public void stopSpeaking() {
            runOnUiThread(() -> { if (textToSpeech != null) textToSpeech.stop(); });
        }
        @JavascriptInterface
        public boolean isSpeechRecognitionAvailable() {
            return SpeechRecognizer.isRecognitionAvailable(MainActivity.this);
        }
        @JavascriptInterface
        public void startListening(String language) {
            runOnUiThread(() -> requestAndStartRecognition(language));
        }
        @JavascriptInterface
        public void stopListening() {
            runOnUiThread(() -> {
                if (speechRecognizer != null) {
                    try { speechRecognizer.stopListening(); } catch (Exception ignored) {}
                }
            });
        }
        @JavascriptInterface
        public void requestRecordingPermission() {
            runOnUiThread(() -> requestRecordingPermissionNative());
        }
        @JavascriptInterface
        public void startRecording() {
            runOnUiThread(() -> startNativeRecording());
        }
        @JavascriptInterface
        public void stopRecording() {
            runOnUiThread(() -> stopNativeRecording());
        }
        @JavascriptInterface
        public void exportRecording(String fileName) {
            runOnUiThread(() -> exportRecordingToMusic(fileName));
        }
    }

    private void speakNative(String text, String language, float rate) {
        if (text == null || text.trim().isEmpty()) {
            notifyJavascript("window.onAndroidTtsError && window.onAndroidTtsError('empty-text')");
            return;
        }
        if (!ttsReady || textToSpeech == null) {
            notifyJavascript("window.onAndroidTtsError && window.onAndroidTtsError('tts-not-ready')");
            return;
        }
        try {
            Locale locale = Locale.forLanguageTag(language == null || language.isEmpty() ? "en-US" : language);
            int languageResult = textToSpeech.setLanguage(locale);
            if (languageResult == TextToSpeech.LANG_MISSING_DATA || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                notifyJavascript("window.onAndroidTtsError && window.onAndroidTtsError('language-not-supported')");
                return;
            }
            textToSpeech.setSpeechRate(Math.max(0.5f, Math.min(1.25f, rate)));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ardyil-tts");
            } else {
                textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null);
            }
        } catch (Exception e) {
            notifyJavascript("window.onAndroidTtsError && window.onAndroidTtsError('tts-error')");
        }
    }

    private void requestAndStartRecognition(String language) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            notifyJavascript("window.onAndroidSpeechError && window.onAndroidSpeechError('unavailable')");
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingRecognitionAfterPermission = true;
            pendingRecognitionLanguage = language == null || language.isEmpty() ? "en-US" : language;
            requestAudioPermission();
            return;
        }
        startRecognition(language);
    }

    private void startRecognition(String language) {
        if (mediaRecorder != null) {
            notifyJavascript("window.onAndroidSpeechError && window.onAndroidSpeechError('busy')");
            return;
        }
        try {
            if (speechRecognizer != null) {
                speechRecognizer.destroy();
                speechRecognizer = null;
            }
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) {
                    notifyJavascript("window.onAndroidSpeechStatus && window.onAndroidSpeechStatus('listening')");
                }
                @Override public void onBeginningOfSpeech() {
                    notifyJavascript("window.onAndroidSpeechStatus && window.onAndroidSpeechStatus('hearing')");
                }
                @Override public void onRmsChanged(float rmsdB) {}
                @Override public void onBufferReceived(byte[] buffer) {}
                @Override public void onEndOfSpeech() {
                    notifyJavascript("window.onAndroidSpeechStatus && window.onAndroidSpeechStatus('processing')");
                }
                @Override public void onError(int error) {
                    notifyJavascript("window.onAndroidSpeechError && window.onAndroidSpeechError('" + speechErrorName(error) + "')");
                }
                @Override public void onResults(Bundle results) {
                    ArrayList<String> matches = results == null ? null :
                            results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String best = (matches == null || matches.isEmpty()) ? "" : matches.get(0);
                    notifyJavascript("window.onAndroidSpeechResult && window.onAndroidSpeechResult(" + JSONObjectQuote.quote(best) + ")");
                }
                @Override public void onPartialResults(Bundle partialResults) {}
                @Override public void onEvent(int eventType, Bundle params) {}
            });
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language == null || language.isEmpty() ? "en-US" : language);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language == null || language.isEmpty() ? "en-US" : language);
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
            speechRecognizer.startListening(intent);
        } catch (Exception e) {
            notifyJavascript("window.onAndroidSpeechError && window.onAndroidSpeechError('start-failed')");
        }
    }

    private File getRecordingsDirectory() {
        File directory = new File(getFilesDir(), "recordings");
        if (!directory.exists() && !directory.mkdirs()) return null;
        return directory;
    }

    /** Serves only generated recording files through the appassets HTTPS origin. */
    private WebResourceResponse openRecordingAsset(String path) {
        if (path == null || !path.matches("[A-Za-z0-9._-]+\\.m4a")) {
            return new WebResourceResponse(null, null, null);
        }
        try {
            File directory = getRecordingsDirectory();
            if (directory == null) return new WebResourceResponse(null, null, null);
            File file = new File(directory, path);
            String root = directory.getCanonicalPath() + File.separator;
            if (!file.getCanonicalPath().startsWith(root) || !file.isFile()) {
                return new WebResourceResponse(null, null, null);
            }
            return new WebResourceResponse("audio/mp4", null, new FileInputStream(file));
        } catch (IOException e) {
            return new WebResourceResponse(null, null, null);
        }
    }

    private void requestAudioPermission() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) return;
        if (permissionRequestInFlight) return;
        permissionRequestInFlight = true;
        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO);
    }

    private void requestRecordingPermissionNative() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            notifyJavascript("window.onAndroidRecordingPermission && window.onAndroidRecordingPermission(true)");
            notifyRecordingStatus("permission-granted");
            return;
        }
        pendingRecordingPermissionCallback = true;
        notifyRecordingStatus("permission-requested");
        requestAudioPermission();
    }

    private void startNativeRecording() {
        if (mediaRecorder != null) {
            notifyRecordingError("already-recording");
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingRecordingStart = true;
            pendingRecordingPermissionCallback = true;
            notifyRecordingStatus("permission-requested");
            requestAudioPermission();
            return;
        }

        // Android speech recognition and MediaRecorder must not hold the microphone simultaneously.
        if (speechRecognizer != null) {
            try { speechRecognizer.cancel(); } catch (Exception ignored) {}
            try { speechRecognizer.destroy(); } catch (Exception ignored) {}
            speechRecognizer = null;
        }

        File directory = getRecordingsDirectory();
        if (directory == null) {
            notifyRecordingError("storage-unavailable");
            return;
        }
        File output = new File(directory, "ardyil-recording-" + System.currentTimeMillis() + ".m4a");
        MediaRecorder recorder = null;
        try {
            recorder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                    ? new MediaRecorder(this) : new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioSamplingRate(44100);
            recorder.setAudioChannels(1);
            recorder.setAudioEncodingBitRate(96000);
            recorder.setOutputFile(output.getAbsolutePath());
            recorder.setOnErrorListener((failedRecorder, what, extra) -> runOnUiThread(() -> {
                if (mediaRecorder == failedRecorder) {
                    releaseRecorder(true);
                    notifyRecordingError("recorder-error");
                }
            }));
            recorder.prepare();
            recorder.start();
            mediaRecorder = recorder;
            activeRecordingFile = output;
            recordingStartedAtMs = System.currentTimeMillis();
            notifyRecordingStatus("recording");
        } catch (Exception e) {
            if (recorder != null) {
                try { recorder.reset(); } catch (Exception ignored) {}
                try { recorder.release(); } catch (Exception ignored) {}
            }
            if (output.exists()) output.delete();
            notifyRecordingError("start-failed");
        }
    }

    private void stopNativeRecording() {
        if (mediaRecorder == null) {
            notifyRecordingStatus("idle");
            return;
        }
        MediaRecorder recorder = mediaRecorder;
        File completedFile = activeRecordingFile;
        long durationMs = Math.max(0L, System.currentTimeMillis() - recordingStartedAtMs);
        boolean completed = false;
        try {
            recorder.stop();
            completed = completedFile != null && completedFile.isFile() && completedFile.length() > 0;
        } catch (RuntimeException e) {
            // MediaRecorder.stop() throws when the user stops before a valid MP4 is finalized.
            if (completedFile != null && completedFile.exists()) completedFile.delete();
        } finally {
            releaseRecorder(false);
        }

        if (!completed) {
            notifyRecordingError("recording-too-short");
            return;
        }
        String fileName = completedFile.getName();
        String url = START_URL.substring(0, START_URL.lastIndexOf("/assets/"))
                + "/recordings/" + fileName;
        long fileSize = completedFile.length();
        notifyJavascript("window.onAndroidRecordingComplete && window.onAndroidRecordingComplete("
                + JSONObjectQuote.quote(url) + "," + JSONObjectQuote.quote(fileName) + ","
                + fileSize + "," + durationMs + ")");
        notifyRecordingStatus("complete");
    }

    private void releaseRecorder(boolean deletePartialFile) {
        MediaRecorder recorder = mediaRecorder;
        File file = activeRecordingFile;
        mediaRecorder = null;
        activeRecordingFile = null;
        recordingStartedAtMs = 0L;
        if (recorder != null) {
            try { recorder.reset(); } catch (Exception ignored) {}
            try { recorder.release(); } catch (Exception ignored) {}
        }
        if (deletePartialFile && file != null && file.exists()) file.delete();
    }

    private void notifyRecordingStatus(String status) {
        notifyJavascript("window.onAndroidRecordingStatus && window.onAndroidRecordingStatus("
                + JSONObjectQuote.quote(status) + ")");
    }

    private void notifyRecordingError(String code) {
        notifyJavascript("window.onAndroidRecordingError && window.onAndroidRecordingError("
                + JSONObjectQuote.quote(code) + ")");
    }

    /** Copies a finished private recording into Music/ARDYIL English Dictionary on Android 10+. */
    private void exportRecordingToMusic(String fileName) {
        if (fileName == null || !fileName.matches("[A-Za-z0-9._-]+\\.m4a")) {
            notifyRecordingError("recording-not-found");
            return;
        }
        File directory = getRecordingsDirectory();
        File source = directory == null ? null : new File(directory, fileName);
        if (source == null || !source.isFile()) {
            notifyRecordingError("recording-not-found");
            return;
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            notifyRecordingError("export-not-supported");
            return;
        }

        String displayName = "ARDYIL-" + System.currentTimeMillis() + ".m4a";
        ContentValues values = new ContentValues();
        values.put(MediaStore.Audio.Media.DISPLAY_NAME, displayName);
        values.put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4");
        values.put(MediaStore.Audio.Media.RELATIVE_PATH,
                Environment.DIRECTORY_MUSIC + "/ARDYIL English Dictionary");
        values.put(MediaStore.Audio.Media.IS_PENDING, 1);
        Uri destination = null;
        try {
            destination = getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values);
            if (destination == null) throw new IOException("Unable to create MediaStore entry");
            try (InputStream input = new FileInputStream(source);
                 OutputStream output = getContentResolver().openOutputStream(destination)) {
                if (output == null) throw new IOException("Unable to open destination");
                byte[] buffer = new byte[8192];
                int count;
                while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
                output.flush();
            }
            ContentValues publishValues = new ContentValues();
            publishValues.put(MediaStore.Audio.Media.IS_PENDING, 0);
            getContentResolver().update(destination, publishValues, null, null);
            notifyJavascript("window.onAndroidRecordingSaved && window.onAndroidRecordingSaved("
                    + JSONObjectQuote.quote(displayName) + ")");
        } catch (Exception e) {
            if (destination != null) {
                try { getContentResolver().delete(destination, null, null); } catch (Exception ignored) {}
            }
            notifyRecordingError("save-failed");
        }
    }

    private String speechErrorName(int error) {
        switch (error) {
            case SpeechRecognizer.ERROR_AUDIO: return "audio";
            case SpeechRecognizer.ERROR_CLIENT: return "client";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "permission";
            case SpeechRecognizer.ERROR_NETWORK: return "network";
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: return "network-timeout";
            case SpeechRecognizer.ERROR_NO_MATCH: return "no-match";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "busy";
            case SpeechRecognizer.ERROR_SERVER: return "server";
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: return "timeout";
            default: return "unknown";
        }
    }

    private void notifyJavascript(String script) {
        runOnUiThread(() -> {
            if (webView != null && !isFinishing()) webView.evaluateJavascript(script, null);
        });
    }

    private static class JSONObjectQuote {
        static String quote(String value) {
            if (value == null) return "\"\"";
            StringBuilder out = new StringBuilder("\"");
            for (int i = 0; i < value.length(); i++) {
                char c = value.charAt(i);
                if (c == '"' || c == '\\') out.append('\\').append(c);
                else if (c == '\n') out.append("\\n");
                else if (c == '\r') out.append("\\r");
                else if (c == '\t') out.append("\\t");
                else if (c < 0x20) out.append(String.format("\\u%04x", (int)c));
                else out.append(c);
            }
            return out.append('"').toString();
        }
    }

    private void configureSystemBars() {
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(23, 21, 43));
        window.setNavigationBarColor(Color.rgb(23, 21, 43));
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.setNavigationBarContrastEnforced(false);
            window.setStatusBarContrastEnforced(false);
        }
    }

    private void handleWebPermissionRequest(PermissionRequest request) {
        if (isFinishing() || isDestroyed()) { request.deny(); return; }
        Uri origin = request.getOrigin();
        if (origin == null || !"https".equalsIgnoreCase(origin.getScheme())
                || !APP_ASSET_HOST.equalsIgnoreCase(origin.getHost())) { request.deny(); return; }
        boolean audioRequested = false;
        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) audioRequested = true;
            else { request.deny(); return; }
        }
        if (!audioRequested) { request.deny(); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            return;
        }
        if (pendingAudioRequest != null) pendingAudioRequest.deny();
        pendingAudioRequest = request;
        requestAudioPermission();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_RECORD_AUDIO) return;
        permissionRequestInFlight = false;
        boolean granted = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        PermissionRequest request = pendingAudioRequest;
        pendingAudioRequest = null;
        if (request != null) {
            if (granted && !isFinishing() && !isDestroyed())
                request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            else request.deny();
        }
        if (pendingRecordingPermissionCallback || pendingRecordingStart) {
            pendingRecordingPermissionCallback = false;
            notifyJavascript("window.onAndroidRecordingPermission && window.onAndroidRecordingPermission("
                    + (granted ? "true" : "false") + ")");
        }
        if (pendingRecordingStart) {
            pendingRecordingStart = false;
            if (granted) startNativeRecording();
            else notifyRecordingError("permission-denied");
        }
        if (pendingRecognitionAfterPermission) {
            pendingRecognitionAfterPermission = false;
            if (granted) startRecognition(pendingRecognitionLanguage);
            else notifyJavascript("window.onAndroidSpeechError && window.onAndroidSpeechError('permission')");
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (pendingAudioRequest != null) { pendingAudioRequest.deny(); pendingAudioRequest = null; }
        if (speechRecognizer != null) { speechRecognizer.destroy(); speechRecognizer = null; }
        if (mediaRecorder != null) releaseRecorder(true);
        if (textToSpeech != null) { textToSpeech.stop(); textToSpeech.shutdown(); textToSpeech = null; }
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidVoice");
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
