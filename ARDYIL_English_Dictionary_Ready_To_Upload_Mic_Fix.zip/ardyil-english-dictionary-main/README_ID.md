# ARDYIL English Dictionary — Paket GitHub siap unggah

Paket ini berisi workflow GitHub Actions dan arsip proyek Android yang sudah diperbarui untuk perekaman mikrofon native.

## Build APK di GitHub

1. Unggah isi folder `ardyil-english-dictionary-main` ke root repository GitHub ARDYIL.
2. Pastikan file `ARDYIL_English_Dictionary_Android_Mic_Recording_Fix.zip` dan `.github/workflows/main.yml` berada di root/path yang benar.
3. Buka tab **Actions**, pilih **Build ARDYIL APK**, lalu tekan **Run workflow**.
4. Setelah workflow selesai, unduh artifact `ARDYIL-English-Dictionary-APK`.

Workflow mengekstrak arsip menggunakan `unzip -q ARDYIL_English_Dictionary_Android_Mic_Recording_Fix.zip -d android-project`.

Untuk membuka proyek secara langsung di Android Studio, gunakan arsip `ARDYIL_English_Dictionary_Android_Mic_Recording_Fix.zip`.
